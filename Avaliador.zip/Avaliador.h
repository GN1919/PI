#ifndef AVALIADOR_H
#define AVALIADOR_H

#include "dstlib_include.h"

int avaliarExpressao(Fila* filaTokens, int* erroDivZero);

#endif

