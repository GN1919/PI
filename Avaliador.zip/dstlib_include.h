#ifndef DSTLIB_INCLUDE_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <ctype.h>
#include "Token.h"
#include "Pilha.h"
#include "Fila.h"
#include "Pilha_int.h"

#endif
